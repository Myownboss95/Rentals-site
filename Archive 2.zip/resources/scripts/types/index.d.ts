export { };

declare global {
    interface Window {
        jQuery: any;
        $: any;
    }
}
