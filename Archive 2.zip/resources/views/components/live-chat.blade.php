{!! $setting?->chat_script !!}
