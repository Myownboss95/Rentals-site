<?php $__env->startComponent('mail::message'); ?>
## Hello <?php echo e($user->first_name); ?>,

Your withdrawal request of <?php echo e('$'.number_format($transaction->amount)); ?> was declined.


We were unable to send the amount to the selected withdrawal method.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/staking/resources/views/emails/withdrawal/declined.blade.php ENDPATH**/ ?>