<?php $__env->startComponent('mail::message'); ?>
## Hello <?php echo e($user->first_name); ?>,

We were unable verify your account, as the documents provided did not meet our criteria.


Provide documents that are issued by a governmental body, and should be clear and visible.


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/staking/resources/views/emails/kyc/declined.blade.php ENDPATH**/ ?>