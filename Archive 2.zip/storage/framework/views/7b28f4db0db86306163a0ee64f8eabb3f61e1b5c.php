<?php $__env->startComponent('mail::message'); ?>
## Howdy <?php echo e($user->first_name); ?>


Your documents have been reviewed, and your account has been verified.

Login, access your dashboard where you can make deposits, subscribe to a trading plan and commence trading.


Warm regards,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/staking/resources/views/emails/kyc/approved.blade.php ENDPATH**/ ?>