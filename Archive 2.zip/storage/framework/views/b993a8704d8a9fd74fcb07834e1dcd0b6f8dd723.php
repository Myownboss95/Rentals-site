<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >
    
    <?php echo vite_tags(e("default")); ?>
    <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
    <?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->head; } ?>

    <style>
        body>div.skiptranslate{
            display: none;
            visibility: hidden;
            height: 0;
            width:0;
        }

        #google_translate_element img{
            display:none;
        }

        body {
            top: 0 !important;
        }
    </style>

</head>

<body class="antialiased bg-gray-900">
    <?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    <?php if (isset($component)) { $__componentOriginalb013490f51a30cb3b5995d67d274073c1a17ea7b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Translations::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('translations'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Translations::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb013490f51a30cb3b5995d67d274073c1a17ea7b)): ?>
<?php $component = $__componentOriginalb013490f51a30cb3b5995d67d274073c1a17ea7b; ?>
<?php unset($__componentOriginalb013490f51a30cb3b5995d67d274073c1a17ea7b); ?>
<?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <?php if (isset($component)) { $__componentOriginalf3fc5353a166fe60517a2e6965ea91e95862e2b6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\LiveChat::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('live-chat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\LiveChat::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3fc5353a166fe60517a2e6965ea91e95862e2b6)): ?>
<?php $component = $__componentOriginalf3fc5353a166fe60517a2e6965ea91e95862e2b6; ?>
<?php unset($__componentOriginalf3fc5353a166fe60517a2e6965ea91e95862e2b6); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if(!auth()?->user()?->is_admin): ?>
            <?php if (isset($component)) { $__componentOriginalf3fc5353a166fe60517a2e6965ea91e95862e2b6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\LiveChat::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('live-chat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\LiveChat::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3fc5353a166fe60517a2e6965ea91e95862e2b6)): ?>
<?php $component = $__componentOriginalf3fc5353a166fe60517a2e6965ea91e95862e2b6; ?>
<?php unset($__componentOriginalf3fc5353a166fe60517a2e6965ea91e95862e2b6); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>

    <script
        type="text/javascript"
        src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"
    ></script>

    <script type="text/javascript">
        window.googleTranslateElementInit = () => {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                // layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>
</body>

</html>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/broker/binotomo/resources/views/app.blade.php ENDPATH**/ ?>