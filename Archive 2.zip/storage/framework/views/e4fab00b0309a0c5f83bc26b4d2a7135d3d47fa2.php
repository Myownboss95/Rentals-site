<?php $__env->startComponent('mail::message'); ?>
<?php echo $mailMessage; ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/broker/binotomo/resources/views/emails/send-mail.blade.php ENDPATH**/ ?>