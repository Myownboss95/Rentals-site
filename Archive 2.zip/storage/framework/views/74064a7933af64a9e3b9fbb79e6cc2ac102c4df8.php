[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/staking/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>