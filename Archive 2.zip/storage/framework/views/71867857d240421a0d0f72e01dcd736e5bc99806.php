<?php echo $setting?->chat_script; ?>

<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/broker/binotomo/resources/views/components/live-chat.blade.php ENDPATH**/ ?>