<?php echo e($slot); ?>

<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/staking/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>