<?php $__env->startComponent('mail::message'); ?>
## Dear <?php echo e($user->first_name); ?>,


Your withdrawal request of <?php echo e('$'.number_format($transaction->amount)); ?> has been approved.


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/staking/resources/views/emails/withdrawal/approved.blade.php ENDPATH**/ ?>