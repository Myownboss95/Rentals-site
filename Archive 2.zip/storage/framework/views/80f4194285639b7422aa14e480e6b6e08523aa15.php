<?php echo e($slot); ?>

<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/broker/binotomo/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>