<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/broker/binotomo/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>