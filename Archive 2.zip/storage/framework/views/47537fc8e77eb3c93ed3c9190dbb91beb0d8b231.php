<script>
    window._translations = <?php echo json_encode($translations, 15, 512) ?>;
</script>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/broker/binotomo/resources/views/components/translations.blade.php ENDPATH**/ ?>