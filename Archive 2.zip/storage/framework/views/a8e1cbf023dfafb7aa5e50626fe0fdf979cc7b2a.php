<script>
    window._translations = <?php echo json_encode($translations, 15, 512) ?>;
</script>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/staking/resources/views/components/translations.blade.php ENDPATH**/ ?>