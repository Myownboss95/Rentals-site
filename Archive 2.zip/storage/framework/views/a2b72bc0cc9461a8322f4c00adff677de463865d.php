<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
    <img src="<?php echo e(asset(config('app.logo'))); ?>" class="logo" alt="Laravel Logo" style="height: 120px; width:150px">

</a>
</td>
</tr>
<?php /**PATH /Users/mac/Desktop/craft 360/Scripts/staking/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>