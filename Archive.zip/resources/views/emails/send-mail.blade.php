@component('mail::message')
{!! $mailMessage !!}
@endcomponent
