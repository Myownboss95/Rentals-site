<template>

</template>

<script setup>
defineProps({
    errors: {}
})
</script>

<style>

</style>
